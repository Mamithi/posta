<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Bulk extends Model
{
    
   public $fillable = ['box','code', 'person_id'];
}
